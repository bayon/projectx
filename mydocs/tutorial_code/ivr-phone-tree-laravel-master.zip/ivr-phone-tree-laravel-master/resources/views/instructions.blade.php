<!DOCTYPE html>
<html>
    <body>
        Call the number you have configured under the
        <a href='https://www.twilio.com/user/account/phone-numbers/incoming'>
        Manage Numbers page in your Twilio account</a> or head to this
        <a href='https://github.com/TwilioDevEd/ivr-phone-tree-laravel/blob/master/readme.md'>
        application's README file in GitHub.</a>
    </body>
</html>
