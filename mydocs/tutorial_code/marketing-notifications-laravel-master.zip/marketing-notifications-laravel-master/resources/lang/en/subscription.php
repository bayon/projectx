<?php

return [

    'thanks'                    => 'Thanks for contacting TWBC! Text \'subscribe\' if you would to receive updates via text message.',
    'unavailable_command'       => 'Sorry, we don\'t recognize that command. Available commands are: \'subscribe\' or \'unsubscribe\'.',
    'subscribed_confirmation'   => 'You are now subscribed for updates',
    'unsubscribed_confirmation' => 'You have unsubscribed from notifications. Text \'subscribe\' to start receiving updates again',

];
