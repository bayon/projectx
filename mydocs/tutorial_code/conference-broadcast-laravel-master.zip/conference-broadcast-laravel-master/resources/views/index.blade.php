@extends('layouts.master')

@section('title')
    Home
@endsection

@section('content')
  <div class="container">
    <div class="row">
        <a class="btn btn-square btn-lg" href="/conference">Conference Line</a>
        <a class="btn btn-square btn-lg" href="/broadcast">Broadcast a Message</a>
    </div>
  </div>
@endsection
