@extends('layouts.master')

@section('title')
    Conference Call
@endsection

@section('content')
    <h1 class="text-center">Conference Line: {{ $conferenceNumber }}</h1>
@endsection('content')
