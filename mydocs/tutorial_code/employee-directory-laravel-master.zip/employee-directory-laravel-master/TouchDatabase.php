<?php

touch(__DIR__.'/storage/app/database.sqlite');