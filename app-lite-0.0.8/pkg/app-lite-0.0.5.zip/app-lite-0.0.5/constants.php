<?php
//CONSTANTS
define('APP_ID','1001');

define('DATABASE','applite');
define('HOST','localhost');
define('USERNAME','root');
define('PASSWORD','');

//STRINGS
define('APP_NAME','s-app TestA');
