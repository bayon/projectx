<?php
include_once('config.php');
include_once('constants.php');
//include_once('./code_reporter.php');
include_once('view_helper.php');

include_once('mySQLi.model.php');
//assets

// CODE WRITER INCLUDES:
require_once "TimelineEvent.controller.php";
require_once "TimelineEvent.model.php";
require_once "Time_dimension.controller.php";
require_once "Time_dimension.model.php";