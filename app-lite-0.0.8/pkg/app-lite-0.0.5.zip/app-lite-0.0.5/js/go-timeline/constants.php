<?php
//CONSTANTS
define('APP_ID','1003');

define('DATABASE','superapp');
define('HOST','localhost');
define('USERNAME','root');
define('PASSWORD','');

//STRINGS
define('APP_NAME','gotimeline');
