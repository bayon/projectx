if ( typeof DESIGN == 'undefined') {
	var DESIGN = {};
}
DESIGN.brand_name='Company X Inc.';
DESIGN.BG_IMG='kiosk_pages_sketch.png';
DESIGN.bg_gradient='gradient2';
DESIGN.LOGO_IMG='logo.svg';
DESIGN.BG_IMG_TOP='kiosk_pages_sketch.png';
DESIGN.BG_IMG_LEFT='asianman1.jpg';
DESIGN.BG_IMG_RIGHT='asianman1.jpg';
