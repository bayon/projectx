<?php
include_once('./config.php');
include_once('./constants.php');
//include_once('./code_reporter.php');
include_once('views/view_helper.php');

include_once('controllers/main.controller.php');
include_once('controllers/Account/Account.controller.php');
//include_once('controllers/user.controller.php');
require_once "includes/controllers/admin.controller.php";

include_once('models/mySQLi.model.php');
include_once('models/Account.model.php');
//include_once('models/user.model.php');
require_once "includes/models/admin.model.php";
 

 
 //assets
require_once "includes/assets/php/Paginator.class.php";

// CODE WRITER INCLUDES:

  
    
require_once "includes/controllers/bigdog.controller.php";
require_once "includes/models/bigdog.model.php";
require_once "includes/controllers/littledog.controller.php";
require_once "includes/models/littledog.model.php";

 