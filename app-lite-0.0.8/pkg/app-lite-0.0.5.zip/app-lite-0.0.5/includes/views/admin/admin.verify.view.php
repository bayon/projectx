<div class="main_content">
	<div id='verify'  class='view_segment view_content'>
		VERIFY
	</div>
</div>
