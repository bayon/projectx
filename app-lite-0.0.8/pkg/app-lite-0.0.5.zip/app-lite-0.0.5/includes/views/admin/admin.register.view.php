<div class="main_content">
	<div id='register'  class='view_segment view_content'>
		REGISTER
	</div>
</div>
