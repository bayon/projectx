<?php // NAVIGATION INCLUDES: ?>
<!--   Code Writer Menu Additions:   -->
 


<!-- -->
 
 
  
 
<li id="bigdog_controller"  class=" menu_item " ><a href="<?=BASE_URL;?>index.php?c=bigdog_controller&m=read">bigdog</a></li>
<li id="littledog_controller"  class=" menu_item " ><a href="<?=BASE_URL;?>index.php?c=littledog_controller&m=read">littledog</a></li>
 