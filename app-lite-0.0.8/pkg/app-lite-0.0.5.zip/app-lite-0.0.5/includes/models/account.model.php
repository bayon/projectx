<?php 
include_once('mySQLi.model.php');

class account extends Model  { 

	private $id;
	private $user_id;
	private $acct_no;
	private $acct_name;
	private $acct_type;
	private $acct_balance;
	private $acct_web;
	private $acct_email;
	private $acct_address;
	private $acct_city;
	private $acct_state;
	private $acct_country;
	private $acct_postal_code;
	private $acct_phone;
	private $acct_created;
	private $acct_updated;

	function __construct(){
		parent::__construct();
	} 
	public function model_connect() {
		return parent::connect();
	}
	function init($id,$user_id,$acct_no,$acct_name,$acct_type,$acct_balance,$acct_web,$acct_email,$acct_address,$acct_city,$acct_state,$acct_country,$acct_postal_code,$acct_phone,$acct_created,$acct_updated){
		$this -> id = $id;
		$this -> user_id = $user_id;
		$this -> acct_no = $acct_no;
		$this -> acct_name = $acct_name;
		$this -> acct_type = $acct_type;
		$this -> acct_balance = $acct_balance;
		$this -> acct_web = $acct_web;
		$this -> acct_email = $acct_email;
		$this -> acct_address = $acct_address;
		$this -> acct_city = $acct_city;
		$this -> acct_state = $acct_state;
		$this -> acct_country = $acct_country;
		$this -> acct_postal_code = $acct_postal_code;
		$this -> acct_phone = $acct_phone;
		$this -> acct_created = $acct_created;
		$this -> acct_updated = $acct_updated;
	} 
	public function set_id($id){
		$this -> id = $id;
	}
	public function get_id(){
		return $this -> id; 
	}
	public function set_user_id($user_id){
		$this -> user_id = $user_id;
	}
	public function get_user_id(){
		return $this -> user_id; 
	}
	public function set_acct_no($acct_no){
		$this -> acct_no = $acct_no;
	}
	public function get_acct_no(){
		return $this -> acct_no; 
	}
	public function set_acct_name($acct_name){
		$this -> acct_name = $acct_name;
	}
	public function get_acct_name(){
		return $this -> acct_name; 
	}
	public function set_acct_type($acct_type){
		$this -> acct_type = $acct_type;
	}
	public function get_acct_type(){
		return $this -> acct_type; 
	}
	public function set_acct_balance($acct_balance){
		$this -> acct_balance = $acct_balance;
	}
	public function get_acct_balance(){
		return $this -> acct_balance; 
	}
	public function set_acct_web($acct_web){
		$this -> acct_web = $acct_web;
	}
	public function get_acct_web(){
		return $this -> acct_web; 
	}
	public function set_acct_email($acct_email){
		$this -> acct_email = $acct_email;
	}
	public function get_acct_email(){
		return $this -> acct_email; 
	}
	public function set_acct_address($acct_address){
		$this -> acct_address = $acct_address;
	}
	public function get_acct_address(){
		return $this -> acct_address; 
	}
	public function set_acct_city($acct_city){
		$this -> acct_city = $acct_city;
	}
	public function get_acct_city(){
		return $this -> acct_city; 
	}
	public function set_acct_state($acct_state){
		$this -> acct_state = $acct_state;
	}
	public function get_acct_state(){
		return $this -> acct_state; 
	}
	public function set_acct_country($acct_country){
		$this -> acct_country = $acct_country;
	}
	public function get_acct_country(){
		return $this -> acct_country; 
	}
	public function set_acct_postal_code($acct_postal_code){
		$this -> acct_postal_code = $acct_postal_code;
	}
	public function get_acct_postal_code(){
		return $this -> acct_postal_code; 
	}
	public function set_acct_phone($acct_phone){
		$this -> acct_phone = $acct_phone;
	}
	public function get_acct_phone(){
		return $this -> acct_phone; 
	}
	public function set_acct_created($acct_created){
		$this -> acct_created = $acct_created;
	}
	public function get_acct_created(){
		return $this -> acct_created; 
	}
	public function set_acct_updated($acct_updated){
		$this -> acct_updated = $acct_updated;
	}
	public function get_acct_updated(){
		return $this -> acct_updated; 
	}

//---USE CASE (instantiate via POST array)---------------
//$account = new account( $_POST['id'], $_POST['user_id'], $_POST['acct_no'], $_POST['acct_name'], $_POST['acct_type'], $_POST['acct_balance'], $_POST['acct_web'], $_POST['acct_email'], $_POST['acct_address'], $_POST['acct_city'], $_POST['acct_state'], $_POST['acct_country'], $_POST['acct_postal_code'], $_POST['acct_phone'], $_POST['acct_created'], $_POST['acct_updated']); 

	 
	public function read($return = "") {
		$con = $this -> model_connect();
		$sql = " SELECT * FROM " . $this -> getDatabase() . ".account ;";
		$data = $this -> exe_sql($con, $sql, $return);
		return $data;
	 
	} 
	
	public function read_id($id="",$return = "") {
		$con = $this -> model_connect();
		$sql = " SELECT * FROM " . $this -> getDatabase() . ".account WHERE id = ".$id.";";
		$data = $this -> exe_sql($con, $sql, $return);
		return $data;
	 
	} 
//---SQL INSERT -------------------------------

	 
	function create($account,$return = "json") {
		$con = $this -> model_connect();
		$sql = "INSERT INTO ".$this -> getDatabase().".account (id,user_id,acct_no,acct_name,acct_type,acct_balance,acct_web,acct_email,acct_address,acct_city,acct_state,acct_country,acct_postal_code,acct_phone,acct_created,acct_updated)
		VALUES('".$account->get_id()."' , '".$account->get_user_id()."' , '".$account->get_acct_no()."' , '".$account->get_acct_name()."' , '".$account->get_acct_type()."' , '".$account->get_acct_balance()."' , '".$account->get_acct_web()."' , '".$account->get_acct_email()."' , '".$account->get_acct_address()."' , '".$account->get_acct_city()."' , '".$account->get_acct_state()."' , '".$account->get_acct_country()."' , '".$account->get_acct_postal_code()."' , '".$account->get_acct_phone()."' , '".$account->get_acct_created()."' , '".$account->get_acct_updated()."' );"; 
	$data = $this -> exe_sql($con,$sql, $return);
		 // in the case of an insert , the return data will be the "last id inserted".
		echo($data);
	 
	 } 
	 function update($account,$return = "json") {
		$con = $this -> model_connect();
		$sql = "UPDATE ".$this -> getDatabase().".account set id = '".$account->get_id()."' , user_id = '".$account->get_user_id()."' , acct_no = '".$account->get_acct_no()."' , acct_name = '".$account->get_acct_name()."' , acct_type = '".$account->get_acct_type()."' , acct_balance = '".$account->get_acct_balance()."' , acct_web = '".$account->get_acct_web()."' , acct_email = '".$account->get_acct_email()."' , acct_address = '".$account->get_acct_address()."' , acct_city = '".$account->get_acct_city()."' , acct_state = '".$account->get_acct_state()."' , acct_country = '".$account->get_acct_country()."' , acct_postal_code = '".$account->get_acct_postal_code()."' , acct_phone = '".$account->get_acct_phone()."' , acct_created = '".$account->get_acct_created()."' , acct_updated = '".$account->get_acct_updated()."'  WHERE id = ".$account->get_id()."";	
		$data = $this -> exe_sql($con, $sql, $return);
 		echo($data);
	}
	 
	function delete($account,$return = "json"){
		$con = $this -> model_connect();
		$sql = "DELETE FROM " . $this -> getDatabase() . ".account WHERE id = " . $account -> get_id() . "  ;";
		$data = $this -> exe_sql($con, $sql, $return);
		echo($data);
	}
	function create_table_Account(){
		$con = $this -> model_connect();
		$sql = " CREATE TABLE IF NOT EXISTS `account` (`id` bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY(`id`), `user_id`  varchar(20) NOT NULL, `acct_no`  varchar(20) NOT NULL, `acct_name`  varchar(20) NOT NULL, `acct_type`  varchar(20) NOT NULL, `acct_balance`  varchar(20) NOT NULL, `acct_web`  varchar(20) NOT NULL, `acct_email`  varchar(20) NOT NULL, `acct_address`  varchar(20) NOT NULL, `acct_city`  varchar(20) NOT NULL, `acct_state`  varchar(20) NOT NULL, `acct_country`  varchar(20) NOT NULL, `acct_postal_code`  varchar(20) NOT NULL, `acct_phone`  varchar(20) NOT NULL, `acct_created`  varchar(20) NOT NULL, `acct_updated`  varchar(20) NOT NULL)
		 ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='viaCodeWriter' AUTO_INCREMENT=1 ; " ;

		$data = $this -> exe_sql($con, $sql, $return);
}
	 }
?>

