<?php 
include_once('mySQLi.model.php');

class littledog extends Model  { 

	private $id;
	private $name;
	private $thing1;
	private $thing2;
	private $parent_id;

	function __construct(){
		parent::__construct();
	} 
	public function model_connect() {
		return parent::connect();
	}
	function init($id,$name,$thing1,$thing2,$parent_id){
		$this -> id = $id;
		$this -> name = $name;
		$this -> thing1 = $thing1;
		$this -> thing2 = $thing2;
		$this -> parent_id = $parent_id;
	} 
	public function set_id($id){
		$this -> id = $id;
	}
	public function get_id(){
		return $this -> id; 
	}
	public function set_name($name){
		$this -> name = $name;
	}
	public function get_name(){
		return $this -> name; 
	}
	public function set_thing1($thing1){
		$this -> thing1 = $thing1;
	}
	public function get_thing1(){
		return $this -> thing1; 
	}
	public function set_thing2($thing2){
		$this -> thing2 = $thing2;
	}
	public function get_thing2(){
		return $this -> thing2; 
	}
	public function set_parent_id($parent_id){
		$this -> parent_id = $parent_id;
	}
	public function get_parent_id(){
		return $this -> parent_id; 
	}

//---USE CASE (instantiate via POST array)---------------
//$littledog = new littledog( $_POST['id'], $_POST['name'], $_POST['thing1'], $_POST['thing2'], $_POST['parent_id']); 

	 
	public function read($return = "") {
		$con = $this -> model_connect();
		$sql = " SELECT * FROM " . $this -> getDatabase() . ".littledog ;";
		$data = $this -> exe_sql($con, $sql, $return);
		return $data;
	 
	} 
	 
	public function read_id($id = "",$return = "") {
		$con = $this -> model_connect();
		$sql = " SELECT * FROM " . $this -> getDatabase() . ".littledog WHERE id='.$_data;";
		$data = $this -> exe_sql($con, $sql, $return);
		return $data;
	 
	} public function read_ModelKV($model='',$k = '',$v='',$return = '') { 
  		$con = $this -> model_connect(); 
    		$sql = ' SELECT * FROM ' . $this -> getDatabase() . '.' . $model . ' WHERE ' . $k . '=' . $v . '; ';  
   		$data = $this -> exe_sql($con, $sql, $return);  
   		return $data; 
    	} 
   
//---SQL INSERT -------------------------------

	 
	function create($littledog,$return = "json") {
		$con = $this -> model_connect();
		$sql = "INSERT INTO ".$this -> getDatabase().".littledog (id,name,thing1,thing2,parent_id)
		VALUES('".$littledog->get_id()."' , '".$littledog->get_name()."' , '".$littledog->get_thing1()."' , '".$littledog->get_thing2()."' , '".$littledog->get_parent_id()."' );"; 
	$data = $this -> exe_sql($con,$sql, $return);
		 // in the case of an insert , the return data will be the "last id inserted".
		echo($data);
	 
	 } 
	 function update($littledog,$return = "json") {
		$con = $this -> model_connect();
		$sql = "UPDATE ".$this -> getDatabase().".littledog set id = '".$littledog->get_id()."' , name = '".$littledog->get_name()."' , thing1 = '".$littledog->get_thing1()."' , thing2 = '".$littledog->get_thing2()."' , parent_id = '".$littledog->get_parent_id()."'  WHERE id = ".$littledog->get_id()."";	
		$data = $this -> exe_sql($con, $sql, $return);
 		echo($data);
	}
	 
	function delete($littledog,$return = "json"){
		$con = $this -> model_connect();
		$sql = "DELETE FROM " . $this -> getDatabase() . ".littledog WHERE id = " . $littledog -> get_id() . "  ;";
		$data = $this -> exe_sql($con, $sql, $return);
		echo($data);
	}
	function create_table_littledog(){
		$con = $this -> model_connect();
		$sql = " CREATE TABLE IF NOT EXISTS `littledog` (`id` bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY(`id`), `name`  varchar(20) NOT NULL, `thing1`  varchar(20) NOT NULL, `thing2`  varchar(20) NOT NULL, `parent_id`  varchar(20) NOT NULL)
		 ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='viaCodeWriter' AUTO_INCREMENT=1 ; " ;

		$data = $this -> exe_sql($con, $sql, $return);
}
	 }
?>

