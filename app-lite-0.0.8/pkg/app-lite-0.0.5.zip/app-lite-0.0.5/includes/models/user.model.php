<?php 
	// - - - -   MODEL PHP  - - - - 
	
include_once('mySQLi.model.php');

class User extends Model  { 

	private $id;
	private $app_id;
	private $username;
	private $password;
	private $settings_id;
	private $contact_id;
	private $date;
	private $last_modified;

	function __construct(){
		parent::__construct();
	} 
	public function model_connect() {
		return parent::connect();
	}
	function init($id='',$app_id='',$username='',$password='',$settings_id='',$contact_id='',$date='',$last_modified=''){
		$this -> id = $id;
		$this -> app_id = $app_id;
		$this -> username = $username;
		$this -> password = $password;
		$this -> settings_id = $settings_id;
		$this -> contact_id = $contact_id;
		$this -> date = $date;
		$this -> last_modified = $last_modified;
	} 
	public function set_id($id){
		$this -> id = $id;
	}
	public function get_id(){
		return $this -> id; 
	}
	public function set_app_id($app_id){
		$this -> app_id = $app_id;
	}
	public function get_app_id(){
		return $this -> app_id; 
	}
	public function set_username($username){
		$this -> username = $username;
	}
	public function get_username(){
		return $this -> username; 
	}
	public function set_password($password){
		$this -> password = $password;
	}
	public function get_password(){
		return $this -> password; 
	}
	public function set_settings_id($settings_id){
		$this -> settings_id = $settings_id;
	}
	public function get_settings_id(){
		return $this -> settings_id; 
	}
	public function set_contact_id($contact_id){
		$this -> contact_id = $contact_id;
	}
	public function get_contact_id(){
		return $this -> contact_id; 
	}
	public function set_date($date){
		$this -> date = $date;
	}
	public function get_date(){
		return $this -> date; 
	}
	public function set_last_modified($last_modified){
		$this -> last_modified = $last_modified;
	}
	public function get_last_modified(){
		return $this -> last_modified; 
	}

//---USE CASE (instantiate via POST array)---------------
//$user = new User( $_POST['id'], $_POST['app_id'], $_POST['username'], $_POST['password'], $_POST['settings_id'], $_POST['contact_id'], $_POST['date'], $_POST['last_modified']); 

	 
	public function read_User($return = "") {
		$con = $this -> model_connect();
		$sql = " SELECT * FROM " . $this -> getDatabase() . ".user ;";
		$data = $this -> exe_sql($con, $sql, $return);
		//return $sql;
		return $data;
	 
	} 
//---SQL INSERT -------------------------------
public function verify($username, $password,$return = "") {
		$con = $this -> model_connect();
		//$sql = " SELECT * FROM " . $this -> getDatabase() . ".user WHERE username LIKE '%".$username."%'  AND password LIKE '%".$password."%';";
		$sql = " SELECT * FROM " . $this -> getDatabase() . ".user WHERE username = '".$username."'  AND password = '".$password."';";
		
		$data = $this -> exe_sql($con, $sql, $return);
		return $data;
	 
	} 
	 
	function create_User($user,$return = "json") {
		$con = $this -> model_connect();
		$sql = "INSERT INTO ".$this -> getDatabase().".user (id,app_id,username,password,settings_id,contact_id,date,last_modified)
		VALUES('".$user->get_id()."' , '".$user->get_app_id()."' , '".$user->get_username()."' , '".$user->get_password()."' , '".$user->get_settings_id()."' , '".$user->get_contact_id()."' , '".$user->get_date()."' , '".$user->get_last_modified()."' );"; 
	$data = $this -> exe_sql($con,$sql, $return);
		 // in the case of an insert , the return data will be the "last id inserted".
		echo($data);
	 
	 } 
	 function update_User($user,$return = "json") {
		$con = $this -> model_connect();
		$sql = "UPDATE ".$this -> getDatabase().".user set id = '".$user->get_id()."' , app_id = '".$user->get_app_id()."' , username = '".$user->get_username()."' , password = '".$user->get_password()."' , settings_id = '".$user->get_settings_id()."' , contact_id = '".$user->get_contact_id()."' , date = '".$user->get_date()."' , last_modified = '".$user->get_last_modified()."'  WHERE id = ".$user->get_id()."";	
		$data = $this -> exe_sql($con, $sql, $return);
 		echo($data);
 		echo($sql);
	}
	 
	function delete_User($user,$return = "json"){
		$con = $this -> model_connect();
		$sql = "DELETE FROM " . $this -> getDatabase() . ".user WHERE id = " . $user -> get_id() . "  ;";
		$data = $this -> exe_sql($con, $sql, $return);
		echo($data);
	}
	function create_table_User(){
		$con = $this -> model_connect();
		$sql = " CREATE TABLE IF NOT EXISTS `user` (`id` bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY(`id`), `app_id`  varchar(20) NOT NULL, `username`  varchar(20) NOT NULL, `password`  varchar(20) NOT NULL, `settings_id`  varchar(20) NOT NULL, `contact_id`  varchar(20) NOT NULL, `date`  varchar(20) NOT NULL, `last_modified`  varchar(20) NOT NULL)
		 ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='viaCodeWriter' AUTO_INCREMENT=1 ; " ;

		$data = $this -> exe_sql($con, $sql, $return);
}
	 }
?>
