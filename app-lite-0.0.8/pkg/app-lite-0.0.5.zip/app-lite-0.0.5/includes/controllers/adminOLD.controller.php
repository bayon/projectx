<?php
	//TIRE CONTROLLER TEMPLATE
	
class admin_controller {
	private $instanceName;
	private $view;
	private $view_dir;
	function __construct() {
		$this -> instanceName = 'default';
		$this -> view = 'admin.view.php';
		$this -> view_dir = 'admin/';
	}
	public function home($_data) {
		$view=$this -> view_dir."admin.home.view.php";
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function read($_data) {
		$view=$this -> view_dir."admin.pagination.view.php";
		 
 		 $admin = new Admin();
 
		$data = $admin-> read();
		$this->buildView($view,$data);
	}
	public function edit($_data) {

		include_once("../models/Admin.model.php");
		$admin = new Admin(); 
		$admin->init($_data['id'],$_data['name'],$_data['app_id'],$_data['username'],$_data['password'],$_data['settings_id'],$_data['acct_id'],$_data['dt_created'],$_data['dt_modified']);
			$admin->set_id($_data['id']);
		$admin ->update($admin);
		unset($admin);
		$view=$this -> view_dir."admin.edit.view.php";
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function create($_data) {
		$view=$this -> view_dir."admin.create.view.php";
 
		 // include main includes for ajax only:
		include("../models/Admin.model.php");
		$admin = new Admin(); 
		$admin->init($_data['id'],$_data['name'],$_data['app_id'],$_data['username'],$_data['password'],$_data['settings_id'],$_data['acct_id'],$_data['dt_created'],$_data['dt_modified']);
		$admin ->create( $admin);
		unset($admin); 
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function delete($_data) {
		$view=$this -> view_dir."admin.delete.view.php";
		include("../models/Admin.model.php");
		$admin = new Admin();
		$admin->set_id($_data['id']);
		$admin ->delete( $admin);
		unset($admin);
		$data = $_data;
		$this->buildView($view,$data);
	}
	////////////////////////////////////////////////
	public function signUp() {
		$view_type = 'signUp';
		$view = $this -> view_dir.'admin.signup.view.php';
		$data='';
 		build_view($view,$data,$view_type);
	}
	public function register() {
		$admin = new Admin();
 		$admin->init(NULL,APP_ID,$_POST['username'],$_POST['password']);
		$admin->create_Admin($admin);
		$view_type = 'register';
		$view = $this -> view_dir.'admin.register.view.php';
		$data='';
		build_view($view,$data,$view_type);
	}
	public function login() {		
		$view_type = 'login';
		$view = $this -> view_dir.'admin.login.view.php';
		$data='';
		build_view($view,$data,$view_type);
	}
	 public function logout() {
	 	session_start();
	    session_unset();
	    session_destroy();
	    session_write_close();
	    setcookie(session_name(),'',0,'/');
	    session_regenerate_id(true);		
		//$view_type = 'login';
		//$view = $this -> view_dir.'admin.main.view.php';
		//$view = "main/main.home.view.php";
		//$data='';
		//build_view($view,$data);
		header('LOCATION:index.php');
	}
   
 
	public function verify() {
		$admin = new Admin();
		$result = $admin->verify($_POST['username'],$_POST['password']);
		//print_r($result);die();
		if($result){
			//echo($result);
			
 			$view = $this -> view_dir.'admin.main.view.php';
			$data='';
			$_SESSION['authorized'] = 1;
			build_view($view,$data);
			
		}else{
			$_SESSION['authorized'] = 0;
 			//$view = $this -> view_dir.'admin.main.view.php';
			//$data='';
			//build_view($view,$data);
			header('LOCATION:index.php');
		}
	} 
	public function paginate($_data) {
				//echo("<pre>"); print_r($_data);echo("</pre>"); 
		//build_view($view,$data);
		$view=$this -> view_dir."admin.pagination.view.php";
		$data=$_data;
		$this->buildView($view,$data);
	}
	
	////////////////////////////////////////////////////
	public function buildView($view='',$data='') { 
		build_view($view,$data);
	}
}
?>
