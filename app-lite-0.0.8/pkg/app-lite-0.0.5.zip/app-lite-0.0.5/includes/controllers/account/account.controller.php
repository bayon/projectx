<?php
	//TIRE CONTROLLER TEMPLATE
	
class account_controller {
	private $instanceName;
	private $view;
	private $view_dir;
	function __construct() {
		$this -> instanceName = 'default';
		$this -> view = 'account.view.php';
		$this -> view_dir = 'account/';
	}
	public function home($_data) {
		echo('home great success!!!');
		$view=$this -> view_dir."account.home.view.php";
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function read($_data) {
		echo('read great success!!!');
		$view=$this -> view_dir."account.pagination.view.php";
		 
 		 $account = new Account();
 
		$data = $account-> read();
		$this->buildView($view,$data);
	}
	public function read_id($_data) {
		header("LOCATION: ?c=account_controller&m=paginate&where=where id=".$_data);
 	}
	public function edit($_data) {
		echo('edit great success!!!');

		include_once("../models/Account.model.php");
		$account = new Account(); 
		$account->init($_data['id'],$_data['user_id'],$_data['acct_no'],$_data['acct_name'],$_data['acct_type'],$_data['acct_balance'],$_data['acct_web'],$_data['acct_email'],$_data['acct_address'],$_data['acct_city'],$_data['acct_state'],$_data['acct_country'],$_data['acct_postal_code'],$_data['acct_phone'],$_data['acct_created'],$_data['acct_updated']);
			$account->set_id($_data['id']);
		$account ->update($account);
		unset($account);
		$view=$this -> view_dir."account.edit.view.php";
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function create($_data) {
		echo('create great success!!!');
		$view=$this -> view_dir."account.create.view.php";
 
		 // include main includes for ajax only:
		include("../models/Account.model.php");
		$account = new Account(); 
		$account->init($_data['id'],$_data['user_id'],$_data['acct_no'],$_data['acct_name'],$_data['acct_type'],$_data['acct_balance'],$_data['acct_web'],$_data['acct_email'],$_data['acct_address'],$_data['acct_city'],$_data['acct_state'],$_data['acct_country'],$_data['acct_postal_code'],$_data['acct_phone'],$_data['acct_created'],$_data['acct_updated']);
		$account ->create( $account);
		unset($account); 
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function delete($_data) {
		echo('delete great success!!!');
		$view=$this -> view_dir."account.delete.view.php";
		include("../models/Account.model.php");
		$account = new Account();
		$account->set_id($_data['id']);
		$account ->delete( $account);
		unset($account);
		$data = $_data;
		$this->buildView($view,$data);
	}
	public function paginate($_data) {
		$view=$this -> view_dir."account.pagination.view.php";
		$data=$_data;
		$this->buildView($view,$data);
	}
	public function buildView($view='',$data='') { 
		build_view($view,$data);
	}
}
?>
