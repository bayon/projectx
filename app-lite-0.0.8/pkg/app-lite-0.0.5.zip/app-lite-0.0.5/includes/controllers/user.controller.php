<?php
class user_controller {
	private $instanceName;
	private $view;
	private $view_dir;
	function __construct() {
		$this -> instanceName = 'default';
		$this -> view = 'user.view.php';
		$this -> view_dir = 'user/';
	}
	public function read() {
		echo('read great success!!!');
		  $data = "";
		$view=$this -> view_dir."user.pagination.view.php";
		$this->buildView($view,$data);
	}
	public function readToJSON() {
		//echo('read great success!!!');
		//$view=$this -> view_dir."user.pagination.view.php";
		 $user = new User();
		 $data = $user->read_User("json");
		echo($data);
		//echo("<script> var USER_DATA = '".$data."'; </script>");
		//$this->buildView($view,$data);
	}
	
	public function edit($_data) {
		//echo('edit great success!!!');
		 $user = new User();
  		$user->init($_data['id'],$_data['app_id'],$_data['username'],$_data['password']); 
		$user->update_User($user);
		echo($_data);
 		
	}
	
	public function create() {
		echo('create great success!!!');
	}
	public function delete($_data) {
		echo('delete great success!!!');
		 $user = new User();
  		$user->init(); 
		$user->set_id($_data['id']); 
		$user->delete_User($user);
		//echo($_data);
	}
	public function signUp() {
		$view_type = 'signUp';
		$view = $this -> view_dir.'user.signup.view.php';
		$data='';
 		build_view($view,$data,$view_type);
	}
	public function register() {
		echo('register great success!!!');
		$user = new User();
 		$user->init(NULL,APP_ID,$_POST['username'],$_POST['password']);
		$user->create_User($user);
		$view_type = 'register';
		$view = $this -> view_dir.'user.register.view.php';
		$data='';
		build_view($view,$data,$view_type);
	}
	public function login() {		
		$view_type = 'login';
		$view = $this -> view_dir.'user.login.view.php';
		$data='';
		build_view($view,$data,$view_type);
	}
	public function verify() {
		echo('verify great success!!!');
		$user = new User();
		$result = $user->verify($_POST['username'],$_POST['password']);
		echo($result);die();
		if($result){
			echo($result);
			$view_type = 'verify';
 			$view = $this -> view_dir.'main.view.php';
			$data='';
			build_view($view,$data,$view_type);
			$_SESSION['authorized'] = 1;
		}else{
			$_SESSION['authorized'] = 0;
 			$view = $this -> view_dir.'main.view.php';
			$data='';
			build_view($view,$data,$view_type);
		}
	} 
	public function paginate($_data) {
			
			//echo("<pre>"); print_r($_data);echo("</pre>"); 
		//build_view($view,$data);
		$view=$this -> view_dir."user.pagination.view.php";
		$data=$_data;
		$this->buildView($view,$data);
	}
	public function buildView($view='',$data='') { 
		build_view($view,$data);
	}
}
?>